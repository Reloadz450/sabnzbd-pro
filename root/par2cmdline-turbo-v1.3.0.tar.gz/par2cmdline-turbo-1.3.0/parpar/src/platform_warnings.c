// dummy compilation unit to display platform warnings
#define PP_PLATFORM_SHOW_WARNINGS
#include "platform.h"
